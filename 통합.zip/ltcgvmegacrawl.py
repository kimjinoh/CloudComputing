import urllib.request
from urllib.request import urlretrieve
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.wait import WebDriverWait
import time

options = Options()
options.headless = True
chrome_driver_path = 'C:/Users/wlsdh/git/python/chromedriver.exe'
driver = webdriver.Chrome(executable_path = chrome_driver_path, options=options)
#driver = webdriver.Chrome(chrome_driver_path)

out=open("timetable.html",'w', -1, "utf-8")
def lottime_request():
    url = 'http://www.lottecinema.co.kr/LCHS/Contents/ticketing/ticketing.aspx#%EC%A0%84%EC%B2%B4'
    lotdate_file_path = 'C:./'
    lotdate_file_name = 'lotdate.txt'
    driver.get(url)
    bsObj = BeautifulSoup(driver.page_source, 'html.parser')
    lotdate_file = open(lotdate_file_path + lotdate_file_name, 'r')
    date = driver.find_element_by_xpath("//*[@id='content']/div[1]/div/div[3]/fieldset/div/label[2]")
    date.click()
    linka = driver.find_element_by_xpath("//*[@id='content']/div[1]/div/div[4]/div/div[1]/div[2]/div[2]/div[1]/ul/li[3]/span/a")
    linka.click()
    aaaa = driver.find_element_by_xpath("//*[@id='content']/div[1]/div/div[4]/div/div[1]/div[2]/div[2]/div[1]/ul/li[3]/div/ul/li[6]/a")
    aaaa.click()
    time.sleep(3)
    location = driver.find_element_by_xpath("//*[@id='content']/div[3]/div[3]/div[2]")

    for p in location.find_elements_by_tag_name('dl'):
        print(p.text.split("\n"), file = out)
    for lotdate_code in lotdate_file.readlines():
        date = driver.find_element_by_xpath("//*[@id='content']/div[1]/div/div[3]/fieldset/div/label["+lotdate_code+"]")
        date.click()
        time.sleep(3)
        location = driver.find_element_by_xpath("//*[@id='content']/div[3]/div[3]/div[2]")
        for q in location.find_elements_by_tag_name('dl'):
            print(q.text.split("\n"), file=out)
def cgvtime_request():
    # date_file_path = 'C:./'
    # date_file_name = 'date.txt'
    # date_file = open(date_file_path + date_file_name,'r')
    date_arr = ['20191129', '20191130', '20191201', '20191202']
    cgv_arr = ['0207', '0007', '0127', '0275', '0091', '0219', '0209', '0044', '0293', '0228', '0297', '0282', '0142', '0294']
    for cgvcode_code in cgv_arr:
        url = 'http://www.cgv.co.kr/common/showtimes/iframeTheater.aspx?areacode=03,205&theatercode=' + cgvcode_code
        for date_code in date_arr:
            url_c = url+'&date='+ date_code
            res = urllib.request.urlopen(url_c).read()
            movie = BeautifulSoup(res, 'html.parser')

            movie = movie.findAll("div", class_="col-times")
            for ul in movie:
                print(ul.text.split("\n"), file=out)
def megatime_request():

    url = 'http://www.megabox.co.kr/?show=booking&p=step1'
    driver.get(url)
    bsObj = BeautifulSoup(driver.page_source, 'html.parser')
    # theater = bsObj.find('div', class_="theater_lst")
    date = driver.find_element_by_xpath("//*[@id='sel_date']/div/ol/li[2]/a")
    date.click()
    time.sleep(1)

    loccc_file_path = 'C:./'
    arrs = ['1', '2', '3']
    for locat in arrs:
        btn2 = driver.find_element_by_xpath("//*[@id='cinemaList']/ul/li[1]/button")
        btn2.click()
        time.sleep(1)
        loc1 = driver.find_element_by_xpath("//*[@id='body_theater1']/div[1]/ul[1]/li[5]/a")
        loc1.click()
        time.sleep(1)
        loccc_file_name = 'megamovie' + locat + '.txt'
        loccc_file = open(loccc_file_path + loccc_file_name, 'r')
        for loccc_code in loccc_file.readlines():
            loca = driver.find_element_by_xpath("//*[@id='body_theater1']/div[1]/ul[2]/li[" + loccc_code + "]/a")
            loca.click()
        check1 = driver.find_element_by_xpath("//*[@id='btnCinemaConfirm']")
        check1.click()
        time.sleep(3)
        location = driver.find_element_by_xpath("//*[@id='movieTimeList']")

        for p in location.find_elements_by_tag_name('li'):
            print(p.text.split("\n"), file=out)
        ref1 = driver.find_element_by_xpath("//*[@id='refreshCinemaBtn']")
        ref1.click()
cgvtime_request()
lottime_request()
megatime_request()